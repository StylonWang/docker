module Rails
  module Html
    class Sanitizer
      VERSION = "1.0.3"
    end
  end
end
