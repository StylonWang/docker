## 1.0.3

* Improved support for Rails 4.2.0.beta2 and above.

## 1.0.2

* Remove warning of method redefined.

## 1.0.1

* Fix autoload issue.
* Added a railtie to eager load the HTML module.

## 1.0.0

* First release
