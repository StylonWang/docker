module Mysql2
  class Result
    include Enumerable
  end
end
