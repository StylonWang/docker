module Arel
  module Nodes
    class RightOuterJoin < Arel::Nodes::Join
    end
  end
end
