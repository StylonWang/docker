module Mysql2
  VERSION = "0.3.20"
end
