module Rack
  class OpenID
    VERSION = "1.4.2"
  end
end
