## 1.0.1

* Added support for Rails 4.2.0.beta2 and above

## 1.0.0

* First release.
